package com.example.edeze_v1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

// db
public class LoginActivity extends AppCompatActivity {
    private static final String TAG = "LoginActivity";

    Button buttonLoginEmail,buttonLoginTwitter,buttonLoginFacebook,buttonLoginGoogle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(TAG, "On Create");
        setContentView(R.layout.activity_login);


        // set UI elements
        buttonLoginEmail = findViewById(R.id.loginEmailButton);
        buttonLoginTwitter = findViewById(R.id.loginTwitterButton);
        buttonLoginFacebook = findViewById(R.id.loginFacebookButton);
        buttonLoginGoogle = findViewById(R.id.loginGoogleButton);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(TAG,"On Start");
    }
    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG,"On Resume");
    }
    @Override
    protected void onPause(){
        super.onPause();
        Log.i(TAG,"On Pause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.i(TAG,"On Stop");
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.i(TAG,"On Destroy");
    }

    public void loginClick(View view) {
        // go to home Q&A feed
        Intent intent = new Intent(this, QAActivity.class);
        startActivity(intent);
    }

    public void loginSSO(View view) {
        Toast.makeText(this, "Not Working Yet", Toast.LENGTH_LONG).show();
    }
}