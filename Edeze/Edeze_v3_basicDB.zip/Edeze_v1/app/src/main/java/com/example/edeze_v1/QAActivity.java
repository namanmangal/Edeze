package com.example.edeze_v1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// db
public class QAActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private static final String TAG = "QAActivity";

    String[] navbar_temp_array;
    LinearLayout linear_layout;
    FirebaseDatabase database;
    DatabaseReference questionRef;
    List<Question> questionIDList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.i(TAG,"On Create");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qna);

        Resources res = getResources();
        navbar_temp_array = res.getStringArray(R.array.navbar_array);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Spinner dropdown = findViewById(R.id.navSpinner);
        dropdown.setOnItemSelectedListener(this);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.navbar_array, android.R.layout.simple_spinner_item);
        dropdown.setAdapter(adapter);

        linear_layout = findViewById(R.id.question_linear_layout);

        database = FirebaseDatabase.getInstance();
        questionRef = database.getReference("question");
        questionIDList = new ArrayList<>();

        //How to add entry in db
//        Map<String, Object> values = new HashMap<>();
//        int input_id = 124;
//        String input_author = "Gagan";
//        String input_title = "Trying to setup FCM";
//        String input_description = "How do I setup FCM with Android Studio?";
//        values.put("id", input_id);
//        values.put("author", input_author);
//        values.put("title", input_title);
//        values.put("description", input_description);
//        questionRef.child("q"+input_id).setValue(values);

        questionRef.addChildEventListener(new ChildEventListener() {

            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String prevChildKey) {
                Question questionPosted = dataSnapshot.getValue(Question.class);
                questionIDList.add(questionPosted);
                TextView textView = new TextView(QAActivity.this);
                textView.setText(questionPosted.id + "---" + questionPosted.author + "---" + questionPosted.title + "---" + questionPosted.description);
                linear_layout.addView(textView);
                System.out.println("ID: " + questionPosted.id);
                System.out.println("Author: " + questionPosted.author);
                System.out.println("Title: " + questionPosted.title);
                System.out.println("Description: " + questionPosted.description);
                System.out.println("Previous Post ID: " + prevChildKey);
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String prevChildKey) {}

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {}

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String prevChildKey) {}

            @Override
            public void onCancelled(DatabaseError databaseError) {}
        });
//        Log.i(TAG,"Trying to populate");
//        for (int i = 0; i < questionIDList.size(); i++) {
//            int id = questionIDList.get(i).id;
//            String author = questionIDList.get(i).author;
//            String title = questionIDList.get(i).title;
//            String description = questionIDList.get(i).description;
//            TextView textView = new TextView(QAActivity.this);
////            Log.i(TAG,"Trying to populate: " + id + " " + author + " " + title + " " + description);
//            textView.setText(id + " " + author + " " + title + " " + description);
//            scroll_view.addView(textView);
//        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(TAG,"On Start");
    }
    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG,"On Resume");
    }
    @Override
    protected void onPause(){
        super.onPause();
        Log.i(TAG,"On Pause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.i(TAG,"On Stop");
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.i(TAG,"On Destroy");
    }
    public void toolbarProfileClick(View view) {
        // go to Profile page
        Intent intent = new Intent(this, ProfileActivity.class);
        startActivity(intent);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
        Context context = getApplicationContext();
        CharSequence text = navbar_temp_array[pos];
        if(text.toString().equals("Main")){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        else if(text.toString().equals("Logout")){
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
        }
        else if(text.toString().equals("Q&A")){
            Intent intent = new Intent(this, QAActivity.class);
            startActivity(intent);
        }
        else if(text.toString().equals("Tutors")){
            Intent intent = new Intent(this, FindTutorActivity.class);
            startActivity(intent);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}