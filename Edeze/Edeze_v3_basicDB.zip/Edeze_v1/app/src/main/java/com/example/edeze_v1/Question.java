package com.example.edeze_v1;

public class Question {
    public int id;
    public String author;
    public String title;
    public String description;

    public void setID(int id) {
        this.id = id;
    }
    public void setAuthor(String author) {
        this.author = author;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public Question(int id, String author, String title, String description){
        this.id = id;
        this.author = author;
        this.title = title;
        this.description = description;
    }
    public Question(){}
}
